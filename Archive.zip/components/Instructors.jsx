"use client"


import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { BookOpen, Play, Clock, Users, Star, Award, Plus, Upload, X } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

export default function Instructors() {
    const [instructors, setInstructors] = useState([
        {
            name: "Oliver Yarbrough, M.S., PMP®",
            title: "AI & Project Management Expert",
            experience: "20+ years leading business transformation & AI adoption",
            avatar: "/oliver_headshot.jpeg",
            bio: "Founder of Not Your Father's A.I., LinkedIn Learning Author, coach and speaker. He helps business leaders bridge AI, project management, and growth strategy.",
            profileLink: "https://www.linkedin.com/in/oliveryarbrough/",
        },
        {
            name: "Marcus Chen",
            title: "Automation Expert",
            experience: "12+ years",
            avatar: "",
            bio: "Built marketing automation systems for Fortune 500 companies and startups alike.",
            profileLink: "",
        },
        {
            name: "Lisa Rodriguez",
            title: "Data Analytics Guru",
            experience: "10+ years",
            avatar: "",
            bio: "Specializes in turning complex data into actionable marketing insights and strategies.",
            profileLink: "",
        },
    ])
    const [isAddInstructorOpen, setIsAddInstructorOpen] = useState(false)
    const [newInstructor, setNewInstructor] = useState({
        name: "",
        title: "",
        experience: "",
        avatar: "",
        bio: "",
        profileLink: "",
    })
    const handleAddInstructor = () => {
        if (newInstructor.name && newInstructor.title && newInstructor.bio) {
            setInstructors([...instructors, { ...newInstructor }])
            setNewInstructor({
                name: "",
                title: "",
                experience: "",
                avatar: "",
                bio: "",
                profileLink: "",
            })
            setIsAddInstructorOpen(false)
        }
    }
    const handleRemoveInstructor = (index) => {
        setInstructors(instructors.filter((_, i) => i !== index))
    }


    const handleInstructorImageUpload = (e) => {
        const file = e.target.files?.[0]
        if (file) {
            const reader = new FileReader()
            reader.onload = (e) => {
                setNewInstructor({ ...newInstructor, avatar: e.target?.result })
            }
            reader.readAsDataURL(file)
        }
    }
    return (
        <div>
            <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-bold">Meet Your Instructors</h2>
                <Dialog open={isAddInstructorOpen} onOpenChange={setIsAddInstructorOpen}>
                    <DialogTrigger asChild>
                        <Button className="bg-[#1a729c] hover:bg-[#1a729c]/90">
                            <Plus className="w-4 h-4 mr-2" />
                            Add New Instructor
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                            <DialogTitle>Add New Instructor</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                            <div>
                                <label className="text-sm font-medium mb-2 block">Instructor Name</label>
                                <Input
                                    placeholder="Enter instructor name"
                                    value={newInstructor.name}
                                    onChange={(e) => setNewInstructor({ ...newInstructor, name: e.target.value })}
                                />
                            </div>

                            <div>
                                <label className="text-sm font-medium mb-2 block">Title/Position</label>
                                <Input
                                    placeholder="e.g., AI & Project Management Expert"
                                    value={newInstructor.title}
                                    onChange={(e) => setNewInstructor({ ...newInstructor, title: e.target.value })}
                                />
                            </div>

                            <div>
                                <label className="text-sm font-medium mb-2 block">Experience</label>
                                <Input
                                    placeholder="e.g., 10+ years experience"
                                    value={newInstructor.experience}
                                    onChange={(e) => setNewInstructor({ ...newInstructor, experience: e.target.value })}
                                />
                            </div>

                            <div>
                                <label className="text-sm font-medium mb-2 block">Bio</label>
                                <Textarea
                                    placeholder="Enter instructor bio"
                                    value={newInstructor.bio}
                                    onChange={(e) => setNewInstructor({ ...newInstructor, bio: e.target.value })}
                                    rows={3}
                                />
                            </div>

                            <div>
                                <label className="text-sm font-medium mb-2 block">Profile Image (Optional)</label>
                                <div className="flex items-center space-x-4">
                                    <Input
                                        type="file"
                                        accept="image/*"
                                        onChange={handleInstructorImageUpload}
                                        className="hidden"
                                        id="instructor-image-upload"
                                    />
                                    <label
                                        htmlFor="instructor-image-upload"
                                        className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-md cursor-pointer hover:bg-gray-50"
                                    >
                                        <Upload className="w-4 h-4" />
                                        <span>Upload Image</span>
                                    </label>
                                    {newInstructor.avatar && (
                                        <img
                                            src={newInstructor.avatar || "/placeholder.svg"}
                                            alt="Preview"
                                            className="w-16 h-16 object-cover rounded-full"
                                        />
                                    )}
                                </div>
                            </div>

                            <div>
                                <label className="text-sm font-medium mb-2 block">Profile Link (Optional)</label>
                                <Input
                                    placeholder="https://linkedin.com/in/username"
                                    value={newInstructor.profileLink}
                                    onChange={(e) => setNewInstructor({ ...newInstructor, profileLink: e.target.value })}
                                />
                            </div>

                            <div className="flex justify-end space-x-2 pt-4">
                                <Button variant="outline" onClick={() => setIsAddInstructorOpen(false)}>
                                    Cancel
                                </Button>
                                <Button onClick={handleAddInstructor} className="bg-[#1a729c] hover:bg-[#1a729c]/90">
                                    Add Instructor
                                </Button>
                            </div>
                        </div>
                    </DialogContent>
                </Dialog>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
                {instructors.map((instructor, index) => (
                    <Card key={index} className="relative">
                        <Button
                            variant="ghost"
                            size="sm"
                            className="absolute top-2 right-2 h-8 w-8 p-0 hover:bg-red-100 hover:text-red-600"
                            onClick={() => handleRemoveInstructor(index)}
                        >
                            <X className="h-4 w-4" />
                        </Button>
                        <CardContent className="p-6 text-center">
                            {instructor.avatar ? (
                                <img
                                    src={instructor.avatar || "/placeholder.svg"}
                                    alt={`${instructor.name} avatar`}
                                    className="w-20 h-20 rounded-full object-cover mx-auto mb-4 border border-[#1a729c]"
                                />
                            ) : (
                                <div className="w-20 h-20 bg-gradient-to-br from-blue-100 to-purple-100 dark:from-blue-900/20 dark:to-purple-900/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                                    <Users className="h-8 w-8 text-[#1a729c]" />
                                </div>
                            )}
                            <h3 className="font-semibold text-lg mb-1">{instructor.name}</h3>
                            <p className="text-[#1a729c] text-sm mb-1">{instructor.title}</p>
                            {instructor.experience && (
                                <p className="text-muted-foreground text-xs mb-3">{instructor.experience} experience</p>
                            )}
                            <p className="text-sm">{instructor.bio}</p>
                            {instructor.profileLink && (
                                <div className="mt-4">
                                    <a
                                        href={instructor.profileLink}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-[#1a729c] hover:underline text-sm"
                                    >
                                        View Profile
                                    </a>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>);
}