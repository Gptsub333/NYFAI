"use client"

import React from "react";
import { useState } from "react";
import { Plus, X, Award } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select"
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog"

export default function Certifications() {
    const [certifications, setCertifications] = useState([
        {
            title: "Certified AI Business Leader",
            description: "Comprehensive certification covering AI tools, strategies, and implementation in marketing.",
            duration: "12 weeks",
            projects: 8,
            badge: "Professional",
            learnMoreUrl: "",
        },
        {
            title: "Advanced Strategic AI Implementation Expert",
            description: "Master-level certification for marketing automation platforms and advanced strategies.",
            duration: "16 weeks",
            projects: 12,
            badge: "Expert",
            learnMoreUrl: "",
        },])

    const [loading, setLoading] = useState(false);
    const [newCertification, setNewCertification] = useState({
        title: "",
        description: "",
        duration: "",
        projects: 0,
        badge: "Professional",
        learnMoreUrl: "",
    })
    const [isAddCertOpen, setIsAddCertOpen] = useState(false)

    const handleAddCertification = () => {
        if (newCertification.title && newCertification.description) {
            setCertifications([...certifications, { ...newCertification }])
            setNewCertification({
                title: "",
                description: "",
                duration: "",
                projects: 0,
                badge: "Professional",
                learnMoreUrl: "",
            })
            setIsAddCertOpen(false)
        }
    }
    const handleRemoveCertification = (index) => {
        setCertifications(certifications.filter((_, i) => i !== index))
    }
    return (
        <div className="mb-16">
            <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-bold">Professional Certifications</h2>
                <Dialog open={isAddCertOpen} onOpenChange={setIsAddCertOpen}>
                    <DialogTrigger asChild>
                        <Button className="bg-[#1a729c] hover:bg-[#1a729c]/90">
                            <Plus className="w-4 h-4 mr-2" />
                            Add New Certification
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                            <DialogTitle>Add New Professional Certification</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                            <div>
                                <label className="text-sm font-medium mb-2 block">Certification Title</label>
                                <Input
                                    placeholder="Enter certification title"
                                    value={newCertification.title}
                                    onChange={(e) => setNewCertification({ ...newCertification, title: e.target.value })}
                                />
                            </div>

                            <div>
                                <label className="text-sm font-medium mb-2 block">Description</label>
                                <Textarea
                                    placeholder="Enter certification description"
                                    value={newCertification.description}
                                    onChange={(e) => setNewCertification({ ...newCertification, description: e.target.value })}
                                    rows={3}
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-sm font-medium mb-2 block">Certification Level</label>
                                    <Select
                                        value={newCertification.badge}
                                        onValueChange={(value) => setNewCertification({ ...newCertification, badge: value })}
                                    >
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="Beginner">Beginner</SelectItem>
                                            <SelectItem value="Professional">Professional</SelectItem>
                                            <SelectItem value="Expert">Expert</SelectItem>
                                            <SelectItem value="Master">Master</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div>
                                    <label className="text-sm font-medium mb-2 block">Program Duration</label>
                                    <Input
                                        placeholder="e.g., 12 weeks, 6 months"
                                        value={newCertification.duration}
                                        onChange={(e) => setNewCertification({ ...newCertification, duration: e.target.value })}
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="text-sm font-medium mb-2 block">Number of Projects</label>
                                <Input
                                    type="number"
                                    placeholder="0"
                                    value={newCertification.projects}
                                    onChange={(e) =>
                                        setNewCertification({ ...newCertification, projects: Number.parseInt(e.target.value) || 0 })
                                    }
                                />
                            </div>

                            <div>
                                <label className="text-sm font-medium mb-2 block">Learn More URL (Optional)</label>
                                <Input
                                    placeholder="https://example.com/certification"
                                    value={newCertification.learnMoreUrl}
                                    onChange={(e) => setNewCertification({ ...newCertification, learnMoreUrl: e.target.value })}
                                />
                            </div>

                            <div className="flex justify-end space-x-2 pt-4">
                                <Button variant="outline" onClick={() => setIsAddCertOpen(false)}>
                                    Cancel
                                </Button>
                                <Button onClick={handleAddCertification} className="bg-[#1a729c] hover:bg-[#1a729c]/90">
                                    Add Certification
                                </Button>
                            </div>
                        </div>
                    </DialogContent>
                </Dialog>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
                {certifications.map((cert, index) => (
                    <Card key={index} className="border-2 border-[#1a729c]/20 relative">
                        <Button
                            variant="ghost"
                            size="sm"
                            className="absolute top-2 right-2 h-8 w-8 p-0 hover:bg-red-100 hover:text-red-600 z-10"
                            onClick={() => handleRemoveCertification(index)}
                        >
                            <X className="h-4 w-4" />
                        </Button>
                        <CardHeader>
                            <div className="flex items-center space-x-2 mb-2">
                                <Award className="h-6 w-6 text-[#1a729c]" />
                                <Badge variant="outline">{cert.badge}</Badge>
                            </div>
                            <CardTitle className="">{cert.title}</CardTitle>
                            <CardDescription>{cert.description}</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                                <span>{cert.duration} program</span>
                                <span>{cert.projects} hands-on projects</span>
                            </div>
                            {cert.learnMoreUrl ? (
                                <a href={cert.learnMoreUrl} target="_blank" rel="noopener noreferrer">
                                    <Button variant="outline" className="w-full bg-transparent text-[#1a729c] border-[#1a729c]">
                                        Learn More
                                    </Button>
                                </a>
                            ) : (
                                <Button variant="outline" className="w-full bg-transparent text-[#1a729c] border-[#1a729c]">
                                    Learn More
                                </Button>
                            )}
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
}