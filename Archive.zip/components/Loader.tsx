// @/components/Loader.tsx

export default function Loader() {
    return <div>Loading...</div>;  // You can replace this with a proper loader component
}
