import ToBeAnnouncedPage from "@/app/tobeannounced/page"

export default function toolsTemplate() {
  return <ToBeAnnouncedPage />
}
